# Written by Hector Hung, Vladislav Adzic,
# Shouri Chatterjee and Professor Peter Kinget
# Copyright (C) 2004-2006 by the authors and
# Columbia Integrated Systems Laboratory
#
# There is no warranty or support and we cannot be held liable in any way.
# Everyone is permitted to copy verbatim copies of the code including
# this message.

package MonteCarloTools;

=head1 NAME

Monte Carlo Tools package

=head1 SYNOPSIS

mct_prepare filter.scs 10 filter.param

mct_simulate

mct_aggregate

mct_graph -f graph.nu -o graph.ps -t 'The Graph' -x 'Frequency' -y 'Voltage' results/RESULTS-net18-magnitude 

=head1 DESCRIPTION

mct is a suite of tools simulating device variations and mismatch in analog integrated circuits. For more information, please visit:

L<http://www.columbia.edu/~va2030/montecarlotools/>

=head1 AUTHORS

Hector Hung <hch2007@columbia.edu>, Vladislav Adzic <vlad@columbia.edu>, Professor Peter Kinget <kinget@ee.columbia.edu>

=head1 SEE ALSO

L<MonteCarloTools>, L<mct_prepare>, L<mct_simulate>, L<mct_aggregate>, L<mct_graph>, L<MonteCarloTools::ParamFile>, L<MonteCarloTools::Parse>, L<MonteCarloTools::Util>

=head1 LICENSE

Written by Hector Hung, Vladislav Adzic, Shouri Chatterjee and Professor Peter Kinget. Copyright (C) 2004-2006 by the authors and Columbia Integrated Systems Laboratory. There is no warranty or support and we cannot be held liable in any way. Everyone is permitted to copy verbatim copies of the code including this message.

=cut

use vars qw($VERSION);
$VERSION="1.0";
