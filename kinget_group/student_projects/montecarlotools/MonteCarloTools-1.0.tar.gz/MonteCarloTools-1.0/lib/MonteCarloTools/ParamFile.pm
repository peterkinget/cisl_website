# Written by Hector Hung, Vladislav Adzic,
# Shouri Chatterjee and Professor Peter Kinget
# Copyright (C) 2004-2006 by the authors and
# Columbia Integrated Systems Laboratory
#
# There is no warranty or support and we cannot be held liable in any way.
# Everyone is permitted to copy verbatim copies of the code including
# this message.

package MonteCarloTools::ParamFile;

=head1 NAME

MonteCarloTools::ParamFile - class to represent a Parameters file

=head1 SYNOPSIS

    use MonteCarloTools::ParamFile;

    open(my $filehandle, "<",$ParametersFile)
    my $deviations = ParamFile->new($filehandle);

    $capictor_deviation = $deviations->getDeviation('C');
    $resistor_shift     = $deviations->getShift('R');

    @voltage_nodes = $deviations->getVNodes;
    @current_nodes = $deviations->getINodes;

    $deviations->getTransistorMode();

    $deviations->getTransistorSubcircuit($mos_model);

    @mos_models = $deviations->getTransistorModels();

    %mos_params = $deviations->getTransistorModelParams($mos_model);

    getDeviationsInfo();

=head1 DESCRIPTION

The module is composed of the Parameters file parser that is used by the Monte Carlo Tools package.

=over 4

=item C<new($filehandle)>

This function creates a new ParamFile object. It will read in all lines in the filehandle and parse them as a Parameters file.

    open(my $filehandle, "<",$ParametersFile)
    my $deviations = ParamFile->new($filehandle);

=item C<getDeviation($elementtype)>

Returns the Deviation values for the specified type. Valid types are 'C' (Capacitor), 'R' (Resistor), and 'I' (Inductor).

    $deviations->getDeviation('C');

=item C<getShift($elementtype)>

Returns the Shift values for the specified type. Valid types are 'C' (Capacitor), 'R' (Resistor), and 'I' (Inductor).

    $deviations->getShift('R');



=item C<getVNodes()>

Returns an array of voltage nodes that were specified within the deviations file.

    @voltage_nodes = $deviations->getVNodes;


=item C<getINodes()>

Returns an array of current nodes that were specified within the deviations file.

    @current_nodes = $deviations->getINodes;


=item C<getTransistorMode()>

Returns the transistor mode that was specified in the deviations file.

    $deviations->getTransistorMode;

The allows for different methods of transistor handling. 


=item C<getTransistorModels()>

Returns an array of strings, which represent the different mos models listed in the deviations file.

    @mos_models = $deviations->getTransistorModels()


=item C<getTransistorModelParams($mos_model)>

Returns a hash of of parameter/value pairs for the specified mos model from the deviations file.

    %mos_params = $deviations->getTransistorModelParams($mos_model);


=item C<getTransistorSubcircuit()>

Returns a string containing the a subcircuit wrapper for the specified mosfet model.

    $deviations->getTransistorSubcircuit($mod_mos);


=item C<getDeviationsInfo()>

(for debugging) Prints a textual summary of the deviations file.

=back

=head1 DEVIATIONS FILE FORMAT

The following is an example that illustrates the deviations file format.

    # This is a sample parameters file
    # blank lines and lines that start with a '#' are ignored

    # The first few lines specify the deviation and shift
    # for capacitors, resistors, and inductors

    # the format of the line is:
    # "device <deviation> <shift>"
    # the numbers are decimal percentages

    capacitor   0.015   0    # this sets capacitor random deviation to
                             # 1.5% and systematic shift to 0%
    resistor    0.10   -0.02 # this sets resistor random deviation to
                             # 10% andsystematic shift to -2%

    # save lines indicate what voltage node or current node to save
    # the format of save lines is:
    # 'save <node>'

    save net18
    save net2

    # all other lines are treated as MOSFET parameter lines
    # file format is:
    # "modelname param1=<value1> param2=<value2> ... paramn=<valuen>'
    # parameters can be passed in any order
    #
    # delvt = V  (systematic part)
    # avt = V*um (random part; Pelgrom area model parameter)
    # db_b = relative units (not pct) (systematic part)
    # Ab = um    (random part; Pelgrom area model parameter)

    nch delvt=0.00 db_b=0.0 avt=0.005 Ab=0.0104
    pch delvt=0.00 db_b=0.0 avt=0.00549 Ab=0.099


=head1 AUTHORS

Hector Hung <hch2007@columbia.edu>, Vladislav Adzic <vlad@columbia.edu>, Professor Peter Kinget <kinget@ee.columbia.edu>

=head1 SEE ALSO

L<MonteCarloTools>, L<mct_prepare>, L<mct_simulate>, L<mct_aggregate>, L<mct_graph>, L<MonteCarloTools::ParamFile>, L<MonteCarloTools::Parse>, L<MonteCarloTools::Util>

=cut


use strict;
use MonteCarloTools::Util;
use vars qw(@ISA @EXPORT @EXPORT_OK);
require Exporter;
@ISA    = qw(Exporter);

#given a file handle, parse the open netlist
sub new
{
    my $self  = shift;
    my $class = ref($self) || $self;
    my $fh = shift
	or die "ParamFile new method must be passed a file handle";
    
    my $obj = bless { deviations => {R => 0,
				     C => 0,
				     I => 0},
		      shifts     => {R => 0,
				     C => 0,
				     I => 0},
		      vnodes => [],
		      inodes => [],
		      transistormode => 0,
		      transistorspecs => {},
		      fh => $fh
		      },  $class;
    
    $obj->_init;
    return $obj;
}

sub _init
{
    my $self= shift;
    my $filehandle = $self->{fh};
    while (defined (my $line = <$filehandle> ))
    {
	#remove comments and trim
	chomp($line);
	$line =~ s/\#.*//;
	$line =~ s/^\s*$//;
	trim($line);

	#ignore blank lines
	next if ($line =~ m/^$/);
	
	#parse capacitor line
	if ($line =~ m/^capacitor/i)
	{
	    @_= split(/\s+/,$line);
	    $self->{deviations}{C} = $_[1];
	    $self->{shifts}{C}     = $_[2];
	}
	#parse resistor line
	elsif ($line =~ m/^resistor/i)
	{
	    @_= split(/\s+/,$line);
	    $self->{deviations}{R} = $_[1];
	    $self->{shifts}{R}     = $_[2];
	}
	#parse inductor line
	elsif ($line =~ m/^inductor/i)
	{
	    @_= split(/\s+/,$line);
	    $self->{deviations}{I} = $_[1];
	    $self->{shifts}{I}     = $_[2];
	}
	#parse save line
	elsif ($line =~ m/^save/i)
	{
	    @_= split(/\s+/,$line);
	    if ($_[1] =~ m/^v/) {
		push(@{$self->{vnodes}},$_[1]);
	    }
	    else {
		push(@{$self->{inodes}},$_[1]);
	    }
	}
	elsif ($line =~ m/^transistormode\s*(\d*)/i)
	{
	    $self->{transistormode}=$1;
	}
	else
	{
	    #get model, then split each token by = to get param=value sets
	    @_= split(/\s+/,$line);
	    my $model = shift(@_);
	    my %params;
	    
	    foreach my $param (@_)
	    {
		my @temp = split(/\s*=\s*/,$param);
		
		for (my $i=0; $i < scalar(@temp); $i+=2)
		{
		    $params{$temp[$i]} = $temp[$i+1];
		}
	    }
	    $self->{transistorspecs}{$model}  = \%params;
	}
    }
    close $self->{fh};
}


#function returns a subcircuit for the specified transistor model
sub getTransistorSubcircuit
{
    my $self    = shift;
    my $mod_mos = shift || return;
    
    return
	"subckt M$mod_mos d g s b\n"
	."	parameters w=1u l=1u ad=1p as=1p pd=1u ps=1u Vt=0 gain=0 // subcircuit parameters\n"
	."	vsub (g gp) vsource dc=Vt\n"
	."	vtest (d dp) vsource dc=0\n"
	."	M$mod_mos (dp gp s b) $mod_mos w=w l=l ad=ad as=as pd=pd ps=ps\n"
	."	F0 (d s) cccs gain=gain probe=vtest\n"
	."ends M$mod_mos\n"
}

sub getTransistorMode
{
    my $self = shift;
    return $self->{transistormode};
}

sub getTransistorModels
{
    my $self = shift;
    return keys (%{$self->{transistorspecs}});
}

sub getTransistorModelParams
{
    my $self  = shift;
    my $model = shift;
    return %{$self->{transistorspecs}->{$model}};
}

sub getDeviation
{
    my $self = shift;
    my $device = shift;
    return $self->{deviations}->{$device};
}

sub getShift
{
    my $self = shift;
    my $device = shift;
    return $self->{shifts}->{$device};
}

sub getVNodes
{
    my $self = shift;
    return @{$self->{vnodes}};
}

sub getINodes
{
    my $self = shift;
    return @{$self->{inodes}};
}

#debug function to print all information parsed from the deviations file
sub getDeviationsInfo
{
    my $self = shift;

    print "============================================================================\n";
    print "Voltage Outputs:\t\t@{$self->{vnodes}}\n";
    print "Current Outputs:\t\t@{$self->{inodes}}\n";
    print "============================================================================\n";
    print "Resistor, Capacitor, Inductor deviations are in relative units (not percent)\n";
    print "i.e. a deviation of 0.10 is a 10pct deviation\n\n";

    print "Component\tRandom Deviation\tSystematic Shift\n";
    print "Resistor\t$self->{deviations}{R}\t\t\t$self->{shifts}{R}\n";
    print "Capacitor\t$self->{deviations}{C}\t\t\t$self->{shifts}{C}\n";
    print "Inductor\t$self->{deviations}{I}\t\t\t$self->{shifts}{I}\n";


    print "============================================================================\n";
    print "Mosfet variations are using the following units: \n";
    print "Threshold: (random part) Avt in V um ; (systematic part) delvt in V \n";
    print "Current Gain: (random part) Ab in um ; (systematic part) db_b in relative units (not pct!)\n";

    my %specs = %{$self->{transistorspecs}};
    foreach my $key (sort keys %specs) {
	print "MOSFET $key\n";
	my %hash = %{$specs{$key}};
	foreach my $param (sort keys %hash) {
	    print "\t$param:       \t$hash{$param}\n";
	}
    }    
    print "=============================================================================\n";
}

1;
