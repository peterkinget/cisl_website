# Written by Hector Hung, Vladislav Adzic,
# Shouri Chatterjee and Professor Peter Kinget
# Copyright (C) 2004-2006 by the authors and
# Columbia Integrated Systems Laboratory
#
# There is no warranty or support and we cannot be held liable in any way.
# Everyone is permitted to copy verbatim copies of the code including
# this message.

package MonteCarloTools::Parse;

=head1 NAME

MonteCarloTools::Parse - class to represent a Netlist file

=head1 SYNOPSIS

    use MonteCarloTools::Parse;

    open(my $filehandle, "<",$InputNetlist)
    my $parser = MonteCarloTools::Parse->new($filehandle);

    my @contents    = @{$parser->getContents};
    my %subcircuits = %{$parser->getSubcircuits};

=head1 DESCRIPTION

The module is composed of the Spectre netlist parser that is used by the Monte Carlo Tools package.

=over 4

=item C<new($filehandle)>

This function creates a new Parser object. The program will read in all lines in the filehandle and parse them as a Spectre netlist.

    open(my $fh, "<",$InputNetlist)
    my $parser = MonteCarloTools::Parse->new($fh);

=item C<getContents()>

Returns an array of entity objects which represent the parsed Spectre Netlist. The entities are found in the same order as were in the Netlist file.

    my @contents    = @{$parser->getContents};


=item C<getSubcircuits()>

Returns a hash of entity objects which represent the subcircuit definitions in the parsed Spectre Netlist. The key is the name of the subcircuit and the value is the correponding entity object.

    my %subcircuits = %{$parser->getSubcircuits};

=back


=head2 ENTITY OBJECTS

=over 4

=item C<Subcircuit Entities>

Subcircuit Entities represent subcircuit definitions. All subcircuit entities have the following structure:

    #string used to differentiate between different entity types
    $entity{type} = 'subcircuit';

    #the name of the subcircuit
    $entity{model} = "SubcircuitName";

    #array of nodes
    $entity{nodes} = ['net_in', 'net_out', 'gnd'];

    #an array of entity objects that compose the subcircuit
    $entity{content} = [ ... ];

    #internal counter used to track the number of subcircuit instances in the netlist
    $entity{count} = 0;

    #the original subcircuit line found in the netlist
    $entity{string} = $line;


=item C<Subcircuit Call Entities>

Subcircuit Call Entities represent calls to subcircuit. All subcircuit call entities have the following structure:

    #string used to differentiate between different entity types
    $entity{type} = 'subcircuitcall';

    #the name of the subcircuit being called
    $entity{model} = "TheSubcircuit";

    #space separated list of nodes being passed to the subcircuit
    $entity{nodes} = "net1 net2 net3";

    #the circuit element name from the netlist (e.g. /^(\S*)\s/)
    $entity{id} = "Imysubcircuit";

    #the original subcircuit call line found in the netlist
    $entity{string} = $line;

=item C<Literal Entities>

Literal Entities represent all other netlist devices. Note that unlike the other types of entities, thorough parsing of literal entities is not done by the parser. This design was chosen in order to simplify the parser, and to make it simpler to adapt to other netlist languages (such as Spice). All subcircuit entities have the following structure

    #string used to differentiate between different entity types
    $entity{type} = 'literal';

    #the original line found in the netlist
    $entity{string} = $line;

=back

=head1 AUTHORS

Hector Hung <hch2007@columbia.edu>, Vladislav Adzic <vlad@columbia.edu>, Professor Peter Kinget <kinget@ee.columbia.edu>

=head1 SEE ALSO

L<MonteCarloTools>, L<mct_prepare>, L<mct_simulate>, L<mct_aggregate>, L<mct_graph>, L<MonteCarloTools::ParamFile>, L<MonteCarloTools::Parse>, L<MonteCarloTools::Util>

=cut

use MonteCarloTools::Util;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
require Exporter;
@ISA    = qw(Exporter);


#given a file handle, parse the open netlist
sub new
{
    my $self  = shift;
    my $class = ref($self) || $self;
    my $fh = shift
	or die "new must be passed a file handle";
    
    my $obj   = bless { contents => [],
                        subcircuits => {},
                        fh => $fh
			},  $class;

    $obj->_recursive_parse($obj->{contents});
    return $obj;
}

sub getContents
{
    my $self = shift;
    return $self->{contents};
}

sub getSubcircuits
{
    my $self = shift;
    return $self->{subcircuits};
}

sub _recursive_parse
{
    my $self = shift;
    my $contents = shift
	or die "_recursive_parse called with invalid contents array";

    while (my $line = getLogicalLine($self->{fh}))
    {
	my %entity;	

	#start parsing a subcircuit
	if ($line =~ m/^subckt/)
	{
	    $entity{type} = 'subcircuit';
	    my @ar = split(m/\s+/,$line);
	    shift @ar;
	    $entity{model} = shift @ar;
	    $entity{nodes} = \@ar;
	    $entity{content} = [];
	    $entity{count} = 0;
	    $entity{string} = $line;
	    $self->_recursive_parse($entity{content});
	    $self->{subcircuits}{$entity{model}} = \%entity;
	}
	#finish parsing a subcircuit
	elsif ($line =~ m/^ends /)
	{
	    return;
	}
	elsif (($line =~ m/^I(\d*) \((.*)\) (.*)/)
	       && ($line !~ m/isource/))
	{
	    $entity{type} = 'subcircuitcall';
	    $entity{string} = $line;
	    $entity{id} = $1;
	    $entity{nodes} = $2;
	    $entity{model} = $3;
	    push(@$contents, \%entity);
	}
	else
	{
	    $entity{type} = 'literal';
	    $entity{string} = $line;
	    push(@$contents, \%entity);
	}
    }
}

1;
