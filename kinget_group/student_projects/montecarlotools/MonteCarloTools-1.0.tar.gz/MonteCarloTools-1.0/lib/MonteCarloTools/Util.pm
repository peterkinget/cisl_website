# Written by Hector Hung, Vladislav Adzic,
# Shouri Chatterjee and Professor Peter Kinget
# Copyright (C) 2004-2006 by the authors and
# Columbia Integrated Systems Laboratory
#
# There is no warranty or support and we cannot be held liable in any way.
# Everyone is permitted to copy verbatim copies of the code including
# this message.

package MonteCarloTools::Util;

=head1 NAME

MonteCarloTools::Util - utility functions used by Monte Carlo Tools

=head1 SYNOPSIS

    use MonteCarloTools::Util;

    open (my $IN, $InputNetlist);
    my $line = getLogicalLine($IN);

    my $trimmed = trim("    string  ");

    my $num1 = randomGaussian();

    my $num2 = spectreToNumber("10p");
    my $num3 = spectreToNumber("2.4M");

=head1 DESCRIPTION

The module is composed of several utility functions used internally by the Monte Carlo Tools package.

=over 4

=item C<getLogicalLine($filehandle)>

This function will read a 'logical line' from the passed file handle. A logical line is composed of one or more lines from the file. The function will read a line and keep concatenating additional lines as long as the last read line ends with a '\'. Blank lines and comment lines are ignored and never returned. Once the EOF is reached, getLogicalLine returns an empty string. It can be used like this:

    open (my $IN, $InputNetlist);
    my $line = getLogicalLine($IN);

=item C<trim($string)>

The function removes all whitespace from the beginning and end of the passed string.

    my $trimmed = trim("    string  ");

=item C<randomGaussian()>

Returns a random number with a Gaussian distribution (mean mu=0 and variance sigma^2=1). Numbers are generated using the Box Muller Transformation.

    my $num = randomGaussian();


=item spectreToNumber($string)

Converts Cadence Spectre style numbers to floating point numbers. Many Spectre netlist numbers contain a suffix, such as 'n' for nano, or 'k' for kilo. This function removes the suffix, multiplies the number by the conversion factor, and returns the result.

    my $num2 = spectreToNumber("10p");
    my $num3 = spectreToNumber("2.4M");

=back

=head1 AUTHORS

Hector Hung <hch2007@columbia.edu>, Vladislav Adzic <vlad@columbia.edu>, Professor Peter Kinget <kinget@ee.columbia.edu>

=head1 SEE ALSO

L<MonteCarloTools>, L<mct_prepare>, L<mct_simulate>, L<mct_aggregate>, L<mct_graph>, L<MonteCarloTools::ParamFile>, L<MonteCarloTools::Parse>, L<MonteCarloTools::Util>

=cut


use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
require Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(getLogicalLine trim 
	     spectreToNumber randomGaussian );


sub getLogicalLine
{
    my $fh = shift or return;
    my $line = '';
    while (<$fh>)
    {
	s/\/\/.*\n//;
	if ( (s/(^.*)\s\\\s*$/$1/) or (m/^\s*$/) )
	{
	    $line .= $_;
	    next;
	}
	$line .= $_;
	last;  
    }
    
    if ($line ne '')
    {
	$line =~ s/\n/ /g;
	$line =~ s/\s+/ /g;
	$line =~ s/^ //g;
	$line =~ s/ $//g;
	return $line;
    }
    close $fh;
    return '';
}


sub trim
{
    my $string = shift || return;
    $string =~ s/\s*$//;
    $string =~ s/^\s*//;
    return $string;
}


sub randomGaussian
{
    my ($u1, $u2);  # uniformly distributed random numbers
    my $w;          # variance, then a weight
    my ($g1, $g2);  # gaussian-distributed numbers

    do
    {
        $u1 = 2 * rand() - 1;
        $u2 = 2 * rand() - 1;
        $w = $u1*$u1 + $u2*$u2;
    } while ( $w >= 1 );
    
    $w = sqrt( (-2 * log($w))  / $w );
    $g2 = $u1 * $w;
    $g1 = $u2 * $w;
    return $g1;
}


sub spectreToNumber
{
    my $number = shift;

    if ($number =~ m/(-?\d*\.?\d*)e(-?\d*)/i)
    {
	my $value = $1;
	my $power = $2;
	return $value * "1e$power";
    }
    
    $number =~ m/(-?\d*\.?\d*)(\w?)/;
    my $value = $1;
    my $suffix = $2;
    return $value if ($suffix eq "");
    
    $value *= 1e-18 if ($suffix =~ s/^a$//);
    $value *= 1e-12 if ($suffix =~ s/^p$//);
    $value *= 1e-9  if ($suffix =~ s/^n$//);
    $value *= 1e-6  if ($suffix =~ s/^u$//);
    $value *= 1e-3  if ($suffix =~ s/^m$//);
    $value *= 1e-2  if ($suffix =~ s/^c$//);
    $value *= 1     if ($suffix =~ s/^_$//);
    $value *= 1e3   if ($suffix =~ s/^k$//i);
    $value *= 1e6   if ($suffix =~ s/^M$//);
    $value *= 1e9   if ($suffix =~ s/^G$//i);
    $value *= 1e12  if ($suffix =~ s/^T$//i);
    return $value;
}

1;
